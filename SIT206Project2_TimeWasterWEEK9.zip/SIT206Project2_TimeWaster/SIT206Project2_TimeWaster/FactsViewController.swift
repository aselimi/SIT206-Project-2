//
//  FactsViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class FactsViewController: UIViewController {
    
    @IBOutlet weak var factView: UITextView!
    
    
    @IBAction func nextButton(_ sender: UIButton) {
        newFact()
    }
    
    
    @IBAction func previousButton(_ sender: UIButton) {
    }
    
    let facts = ["Albania was tribal until the 20th century",
                 "Australia has over 10,000 beaches, you could visit a new beach every day for 27 years",
                 "The national animal of Scotland is the unicorn",
                 "Surgeons who play video games at least 3 hours a week perform 27% faster and make 37% fewer errors",
                 "Sonic the Hedgehog has registered itself in the Guiness world record book as the fastest video game character"]
    
    var currentFact = 0
    
    
    func newFact() {
        
        factView.text = facts[currentFact]
        
        if (currentFact == facts.count)
        {
            print("All done")
        }
        
        if currentFact < facts.count {
            currentFact += 1
        }
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
        newFact()
    }

    func BackgroundImage() {
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
