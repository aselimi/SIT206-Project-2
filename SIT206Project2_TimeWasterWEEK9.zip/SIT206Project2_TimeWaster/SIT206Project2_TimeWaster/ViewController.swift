//
//  ViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 26/4/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

// Main Menu Screen


// This class contains the code to segue between the various view controllers

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.BackgroundImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func BackgroundImage() {
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    

    @IBAction func factsButton(_ sender: UIButton) {
        performSegue(withIdentifier: "factSegue", sender: self)
        
    }
    
    
    @IBAction func backButton(_ sender: UIButton) {
        performSegue(withIdentifier: "backButton", sender: self)
        
    }
    
    
    
    @IBAction func triviaButton(_ sender: UIButton) {
        performSegue(withIdentifier: "triviaSegue", sender: self)
        
    }
    
    
    @IBAction func leaderboardButton(_ sender: UIButton) {
        performSegue(withIdentifier: "leaderSegue", sender: self)
        
    }
    
    
    @IBAction func settingsButton(_ sender: UIButton) {
        performSegue(withIdentifier: "settingsSegue", sender: self)
        
    }
}

