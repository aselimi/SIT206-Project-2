//
//  SettingsViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
    
    // set default background image
    func BackgroundImage() {
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    @IBOutlet weak var A: RoundedButtons!
    
    // set background to A and text color to red
    @IBAction func choosebgA(_ sender: UIButton)
    {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        A.setTitleColor(UIColor.red, for: .normal)
        B.setTitleColor(UIColor.red, for: .normal)
        C.setTitleColor(UIColor.red, for: .normal)
        D.setTitleColor(UIColor.red, for: .normal)
        dInfo.setTitleColor(UIColor.red, for: .normal)
        customLabel.textColor = UIColor.red
        headingSettings.textColor = UIColor.red
        otherLabel.textColor = UIColor.red
        btnStyle.textColor = UIColor.red
    }
    
    @IBOutlet weak var btnStyle: UILabel!
    @IBOutlet weak var B: RoundedButtons!
    
    // set background to b and text colour to gray
    @IBAction func choosebgB(_ sender: UIButton) {
        //
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        A.setTitleColor(UIColor.gray, for: .normal)
        B.setTitleColor(UIColor.gray, for: .normal)
        C.setTitleColor(UIColor.gray, for: .normal)
        D.setTitleColor(UIColor.gray, for: .normal)
        dInfo.setTitleColor(UIColor.gray, for: .normal)
        customLabel.textColor = UIColor.gray
        headingSettings.textColor = UIColor.gray
        otherLabel.textColor = UIColor.gray
        btnStyle.textColor = UIColor.gray
    }
    
    
    @IBOutlet weak var C: RoundedButtons!
    // set background to C and text colour to yellow
    @IBAction func choosebgC(_ sender: UIButton) {
        //
        if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        A.setTitleColor(UIColor.yellow, for: .normal)
        B.setTitleColor(UIColor.yellow, for: .normal)
        C.setTitleColor(UIColor.yellow, for: .normal)
        D.setTitleColor(UIColor.yellow, for: .normal)
        dInfo.setTitleColor(UIColor.yellow, for: .normal)
        customLabel.textColor = UIColor.yellow
        headingSettings.textColor = UIColor.yellow
        otherLabel.textColor = UIColor.yellow
        btnStyle.textColor = UIColor.yellow
    }
    
    // outlet declarations
    @IBOutlet weak var headingSettings: UILabel!
    @IBOutlet weak var customLabel: UILabel!
    @IBOutlet weak var otherLabel: UILabel!
    @IBOutlet weak var dInfo: RoundedButtons!
    @IBOutlet weak var D: RoundedButtons!
    
    // choose default background image and set text colour to blue
    @IBAction func choosebgD(_ sender: UIButton) {
        BackgroundImage()
        A.setTitleColor(UIColor.blue, for: .normal)
        B.setTitleColor(UIColor.blue, for: .normal)
        C.setTitleColor(UIColor.blue, for: .normal)
        D.setTitleColor(UIColor.blue, for: .normal)
        dInfo.setTitleColor(UIColor.blue, for: .normal)
        customLabel.textColor = UIColor.blue
        headingSettings.textColor = UIColor.blue
        otherLabel.textColor = UIColor.blue
        btnStyle.textColor = UIColor.blue
    }
    
    
    @IBOutlet weak var test: UISwitch!
    // if switch is on, round buttons, if switch is off, rectangle buttons
    @IBAction func changeButtons(_ sender: UISwitch) {
        if test.isOn {
            A.cornerRadius = 10
            B.cornerRadius = 10
            C.cornerRadius = 10
            D.cornerRadius = 10
            dInfo.cornerRadius = 10
        }
        else
        {
            A.cornerRadius = 0
            B.cornerRadius = 0
            C.cornerRadius = 0
            D.cornerRadius = 0
            dInfo.cornerRadius = 0
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // alert to show developer information
    @IBAction func devInfo(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: "Developer Information", message:
            "SIT206 Project 2 Created By Alush Selimi 215088485 Version 1.0", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


}
