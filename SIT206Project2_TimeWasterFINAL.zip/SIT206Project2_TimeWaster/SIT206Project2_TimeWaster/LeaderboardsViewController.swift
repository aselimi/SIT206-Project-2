//
//  LeaderboardsViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class LeaderboardsViewController: UIViewController, UITableViewDataSource {
    
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
    
    // set default background
    func BackgroundImage() {
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    // users + scores for leaderboards
    let users = ["notHacked: 9999999", "Legit123: 10000", "JohnSmith: 8451", "nataS: 6666", "Beak: 3000", "Simsal: 1234", "RandomWords234: 145", "Test: 100", "X_Example_X: 12", "user1: 6", "user2: 3"]
    
    
    // set background to option A and text to red
    @IBAction func btnA(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        headingLB.textColor = UIColor.red
    }
    
    // set background to option B and text to gray
    @IBAction func btnB(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        headingLB.textColor = UIColor.gray
    }
    
    // set background to option C and text to yellow
    @IBAction func btnC(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        headingLB.textColor = UIColor.yellow
    }
    
    // set back to default with blue text
    @IBAction func btnD(_ sender: UIButton) {
        BackgroundImage()
        headingLB.textColor = UIColor.blue
    }
    
    // outlet declarations
    @IBOutlet weak var headingLB: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    // set table header
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Leaderboards"
    }
    
    // function to return count of array
    func numberorCount(in tableView: UITableView) -> Int {
        return users.count
    }
    
    //  get number of rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0: return users.count
        default:
            return 0
        }
    }
    
    // add data to the cells 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = users[indexPath.row]
            break
        default:
            break
        }
        
     return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
