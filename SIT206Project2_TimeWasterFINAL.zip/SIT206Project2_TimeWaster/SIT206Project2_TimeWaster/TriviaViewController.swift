//
//  TriviaViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {
    
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)

    // array containing questions (150 questions) 
    let questions = ["Which tv gangster owns a nightclub called the Ba Da Bing?",
                     "Andrew Patterson wrote which Australian song?",
                     "The Sumi people live were?",
                     "Pomono was the roman godess of what?",
                     "Peter Parker is the alter ego of which superhero?",
                     "where is king arthur supposed to be resting?",
                     "which country's name translates to land of the eagle?",
                     "Dalmatian dogs originated in which country?",
                     "Bruce Lee's first film was? ",
                     "Tefnut was the egyptian godess of what?",
                     "who sang Proud Mary?",
                     "Istanbul and Constantinople are two of this city's names, what else was it known as?",
                     "The Smurfs were invented in Belgium in what year?",
                     "At MacDonald’s what is served in a blue wrapper?",
                     "In Happy Days what is Potsies full name?",
                     "Who wrote Johnny Be Good?",
                     "who wrote the novel the betsy?",
                     "Skopje is the capital of where?",
                     "What european country has no rail lines?",
                     "Vaduz is the capital of what country?",
                     "What nationality was Cleopatra?",
                     "Popular song Sandstorm was created by?",
                     "Who ordered the building of the tower of London?",
                     "Five out of six of the village people have what?",
                     "Who was known as the man in black?",
                     "What is the symbol of medicine?",
                     "What is the fastest racket sport?",
                     "A shroff is an expert in what?",
                     "What is the busiest highway in the USA? (Hint: its also a bridge)",
                     "What is Homer Simpsons greatest fear?",
                     "What does IOU stand for?",
                     "Francis Galton first classified what?",
                     "A sufferer of Boanthropy believes they are what?",
                     "What did Barbie do in 1977?",
                     "Alfred Hormel invented what?",
                     "What is the first line on Mel Blancs tombstone?",
                     "What country produces the most full length feature films?",
                     "What does roulette mean?",
                     "Homer Simspons bowling team is called the?",
                     "A kayser measures what?",
                     "What is the common name for an integrated circuit?",
                     "What metal is best conductor of electricity?",
                     "What is Pancetta?",
                     "What is the largest country in Africa? ",
                     "What is the main flavour of aioli?",
                     "Ad hoc translates to what? ",
                     "What does the word rabbi mean?",
                     "Hibernia was the roman name for which country?",
                     "In France what is a framboise?",
                     "What is the hindu kush?",
                     "Bob Clampett created which character in 1938?",
                     "What country do great danes come from?",
                     "What country invented phone cards?",
                     "What is the longest river in Australia?",
                     "What is Kabuki in Japan?",
                     "Where was Houdini born?",
                     "What was discovered at Qumran?",
                     "What does karaoke mean literally?",
                     "What Japanese word means good for nothing?",
                     "In what country is legoland located?",
                     "What animal lives in a drey?",
                     "If someone said they were from Hellas, which country would that be?",
                     "What is a baby whale called?",
                     "What is Ikebana?",
                     "The Pica Pica is what bird?",
                     "What wood is plywood mostly made from?",
                     "What sport are left handed people banned from playing? ",
                     "In China what colour does the bride traditionally wear?",
                     "What winter game is known as the roaring game?",
                     "What is the worlds largest sea in area?",
                     "What feature of a triangle makes it scalene?",
                     "What has the last european nation to accept the potato?",
                     "James Outram invented what?",
                     "What is a smew?",
                     "What does the term soviet mean?",
                     "What insect has the best eyesight?",
                     "Nephologists study what?",
                     "What is a dolly varden?",
                     "Josip Broz Tito founded what?",
                     "The peacock is the national bird of which country?",
                     "Reykjavik is heated by what?",
                     "Herotodus is regarded as the father of what?",
                     "What is a flemish giant?",
                     "Where would you find a waloon?",
                     "What did the ancient greeks use instead of soap?",
                     "In What country is the language Fanti spoken?",
                     "The word bungalow comes from which language?",
                     "The word caravan comes from which language?",
                     "What is a travelator?",
                     "What is the capital of Chechnya?",
                     "Under the snow and ice Antartica is actually a?",
                     "What was the Ancient Persian new years day gift?",
                     "The tarantella supposedly cures what?",
                     "What is the offical food in the state of Texas?",
                     "All living things contain this essentail thing?",
                     "Noologists study what?",
                     "In Queensland Australia, what must all pubs have? ",
                     "Aerology is the study of what?",
                     "Where does the word cop come from?",
                     "Who built the city of Babylon?",
                     "Old superstition? a sneezing cat means what?",
                     "Old superstition? whistling at night means?",
                     "Stamp collecting started out in which country?",
                     "Who said, remember time is money?",
                     "Where was Bacardi made?",
                     "Narcotics comes from greek word meaning to?",
                     "Mario first appeared in what video game?",
                     "What Australian town was named Stuart until 1925?",
                     "What was Zorro's horse called?",
                     "What is the worlds tallest horse?",
                     "What is the most popular Mexican beer in the USA?",
                     "What European language is unrelated to any other language?",
                     "What is a roker?",
                     "What is the worlds largest food company?",
                     "What is the offical state fruit of Louisiana?",
                     "What was the first food consumed on the moon in Apollo 11?",
                     "In what country would you find lake Dissapointment?",
                     "In Finland, Santa Claus rides a what?",
                     "What is the capital of the United Arab Emirates?",
                     "Who is the patron saint of sailors?",
                     "The star Spica is in which constellation?",
                     "The treaty of Paris ended which war?",
                     "That is the test applied to computers to see if they can think?",
                     "45% of americans use what every day?",
                     "After water what is the most consumed beverage?",
                     "What was the first video played on MTV?",
                     "What country makes Sukhindol wine?",
                     "In which city would you find the Blue Mosque?",
                     "The other proposed name for the United Nations was?",
                     "In Australian slang, what is a dishlicker?",
                     "The Celica is made by which car company?",
                     "What was the first James Bond book?",
                     "What country do sinologists study?",
                     "What Australian prime minister drowned near Melbourne?",
                     "What is interesting about Spain's national anthem?",
                     "In high school, Robin Williams was voted what by his peers? ",
                     "The dot found in the letters i and j are called what?",
                     "How many different kinds of kanagaroo can be found in Australia?",
                     "How many continents are there?",
                     "What colour is an octopus' blood?",
                     "The # Symbol is called what?",
                     "40% of MacDonalds profit come from selling what?",
                     "What is so special about honey?",
                     "Who is Aladdins father?",
                     "What does KFC stand for?",
                     "In mythology, what is Hercules famous for?",
                     "In scrabble, what letters are worth 10 points?",
                     "What european city is known as the golden city?",
                     "Galileo was born in which city?"]
    
    // array containing answers to the questions
    let answers = [["Silvio Dante", "Tony Soprano", "Henry Hill", "Ace Rothstein"],
        ["Waltzing Matilda", "24K Magic", "Proud Mary", "Cut It Short"],
        ["Lapland", "Prague", "Naples", "Alice Springs"],
        ["Fruit Trees", "Fertility", "Olives", "Sky"],
        ["Spiderman", "Superman", "Batman", "Ironman "],
        ["Avalon", "London", "Brussels", "Athens"],
        ["Albania","Serbia","Poland","Romania"],
        ["Croatia", "Italy", "Slovenia", "Bosnia"],
        ["Enter The Dragon", "Rush Hour", "Rocky", "Scarface"],
        ["Rain", "Nuts", "Fire", "Thunder"],
        ["Creedence", "Michael Jackson", "Will Smith", "ACDC"],
        ["Byzantium", "Troy", "Thracia", "Dacia"],
        ["1957","1920","1980","1845"],
        ["Filet of fish", "MCchicken with cheese", "cheeseburger", "quarter pounder"],
        ["Warren Webber", "Warren Potsies", "Warren Patrick", "Warren Stevens"],
        ["Chuck Berry", "Bo Diddley", "Little Richard", "Bing Crosby"],
        ["Harold Robbins", "Charles Dickens", "Marie Cuire", "Agatha Christie"],
        ["FYR Macedonia", "Greece", "Kosovo", "Lithuania"],
        ["San Marino", "Vatican City", "Luxembourg", "Czechia"],
        ["Liechtenstein", "Laos", "Luxembourg", "Croatia"],
        ["Greek", "Egyptian", "Minoan", "Thracian"],
        ["Darude", "Avicii", "DJ Infinity", "DJ Lazlow"],
        ["William The Conqueror", "Richard the Lionheart", "Richard III", "Henry VIII"],
        ["Moustache", "Grammy", "Lifelong YMCA membership", "Disease"],
        ["Johnny Cash", "Will Smith", "Jack Sparrow", "Steve Jobs"],
        ["Snake", "Syringe", "Sponge", "Stapler"],
        ["Badminton", "Tennis", "Football", "Table tennis"],
        ["Testing Coins", "Testing Beer", "Testing Food", "Testing Weather"],
        ["New Yorks George Washington", "Interstate 200", "LA Freeway", "Golden Gate"],
        ["Sock Puppets", "Aliens", "Diet", "Prohibition"],
        ["I OWE UNTO", "I OWE YOU", "I OWE UNIVERSAL", "I OWE UPTO"],
        ["Fingerprints", "DNA", "Hydrogen", "Oxygen"],
        ["An Ox", " A Cow", "A frog", "A boat"],
        ["Smile", "Get License", "Buy House", "Get Arrested"],
        ["Spam", "Stapler", "Home", "Bricks"],
        ["Thats all folks", "thanks", "so long", "farewell"],
        ["India", "China", "USA", "Germany"],
        ["Little Wheel", "Spinning Wheel", "Red and Black Wheel", "Other Wheel"],
        ["Pinpals", "The Bee Sharps", "Drunk Guys", "Simpson and Co"],
        ["Waves", "Water Pressure", "Wind Pressure", "Blood Pressure"],
        ["A Chip", "A Circuit", "An Integ", "A thingy"],
        ["Silver", "Copper", "Water", "Platinum"],
        ["Bacon", "Cheese", "Cured Meat", "Dough"],
        ["Sudan", "Egypt", "Tunisia", "Congo"],
        ["Garlic", "Chili", "Sweet", "Sour"],
        ["For this special purpose", "Locally", "Seven", "Tommorow"],
        ["My Master", "Wise Old Man", "Rich man", "neither "],
        ["Ireland", "Spain", "France", "Portugal"],
        ["Raspberry", "Apple", "Crepe", "Orange"],
        ["Mountain Range", "Illicit Drug", "Food", "Wine"],
        ["Bugs Bunny", "Daffy Duck", "Tweedy", "Jeff Clampet"],
        ["Germany", "Denmark", "Sweden", "Finland"],
        ["Italy", "Germany", "Greece", "India"],
        ["Murray Darling", "Yarra", "Nile", "Danube"],
        ["Commoners Theatre", "Sushi", "Noodle", "Car"],
        ["Hungary", "Romania", "Slovakia", "Serbia"],
        ["Dead Sea Scrolls", "Jesus' Tomb", "Alien Technology", "Noah's Ark"],
        ["Empty Orchestra", "Empty Room", "Singer", "Sing Loud  "],
        ["Yakuza", "Senpai", "Nani", "Tekken"],
        ["Denmark", "Melbourne", "England", "Ireland"],
        ["Squirrel", "Pigeon", "Dog", "Cat"],
        ["Greece", "Turkey", "Albania", "Romania"],
        ["Calf", "Cow", "Cat", "Muscle"],
        ["Flower Arranging", "Salami", "Cheese", "Sword"],
        ["Magpie", "Sparrow", "Swallow", "Raven"],
        ["Birch", "Spruce", "Oak", "Pine"],
        ["Polo", "Tennis", "Cricket", "Badminton"],
        ["Red", "Blue", "Yellow", "Orange"],
        ["Curling", "Hockey", "Football", "Cricket"],
        ["South China Sea", "Black Sea", "Red Sea", "Dead Sea"],
        ["Different Side lengths", "all right angles", "same side lengths", "same angles"],
        ["France", "Ireland", "Russia", "Portugal"],
        ["Tramways", "Jam", "Car", "Solar Power"],
        ["Wild Duck", "Wild Turkey", "Wild Chicken", "Wild Animal"],
        ["Workers Council", "Communist", "Russian", "Unified"],
        ["Dragonfly", "Ant", "Spider", "Centipede"],
        ["Clouds", "Dead People", "Nephews", "Flowers"],
        ["Large Hat", "Food", "Cocktail", "Golf Score"],
        ["Yugoslavia", "The Jackson Five", "Communism", "Earth"],
        ["India", "Mexico", "Australia", "China"],
        ["Volcanic Springs", "Wood Fire", "Ducted Heating", "Sun"],
        ["History", "Geography", "Cartography", "Steganography"],
        ["Rabbit", "Hare", "Turtle", "Bear"],
        ["Southern Belgium", "South Australia", "South America", "South India"],
        ["Olive Oil", "Candle Wax", "Limestone", "Shampoo"],
        ["Ghana", "Congo", "South Africa", "Egypt"],
        ["Hindi", "Arabic", "Greek", "English"],
        ["Arabic", "Spanish", "Turkish", "Manadarin"],
        ["Horizontal Escalator", "Travel Car", "Circus", "neither"],
        ["Grozny", "Chechenburg", "Dagestan", "Sevilla"],
        ["Desert", "City", "Portal", "Macdonalds"],
        ["Eggs", "Lamb", "Goat", "Cheese"],
        ["Spider Bite", "Hunger", "Curse", "Indigestion"],
        ["Chilli", "Barbecue", "Tacos", "Burger"],
        ["Water", "Oxygen", "Cheese", "Blood"],
        ["The Mind", "Cows", "The Moon", "Canines"],
        ["Hitching Rail", "TVs", "breath testing", "Food"],
        ["Planet Mars", "Air", "Airplanes", "Aero Candy"],
        ["Constable on Patrol", "Policeman", "Commander", "Copper"],
        ["Nimrod", "Babylonia", "Vegas", "Belgrade"],
        ["Rain", "Death", "Hardship", "Snow"],
        ["Ghosts/Demons", "Happiness", "Hunger", "Money"],
        ["France", "USA", "Panama", "Canada"],
        ["Benjamin Franklin", "Morgan Freeman", "Michael Jordan", "OJ Simpson"],
        ["Cuba", "Australia", "Japan", "Vietnam"],
        ["Eel on forehead", "take drugs", "hurt people", "lie"],
        ["Donkey Kong", "Super Mario Bros", "GTA", "Flappy Bird"],
        ["Alice Springs", "Dubbo", "Mildura", "Bendigo"],
        ["Phantom", "Zorse", "Horsey", "Nayy"],
        ["Shire Horse", "Other Horse", "Pony", "Donkey"],
        ["Corona", "Heineken", "Fosters", "VB"],
        ["Basque", "Albanian", "Lithuanian", "Greek"],
        ["Footlong Ruler", "rake", "lakeside house", "Neither"],
        ["Nestle", "MacDonalds", "KFC", "Hero Group"],
        ["Strawbrery", "Corn", "Apple", "Pear"],
        ["Turkey", "Burger", "Chicken", "Potato Chip"],
        ["Australia", "Canada", "Germany", "Sweden"],
        ["Goat", "Dog Sleigh", "Bear", "Unicorn"],
        ["Abu Dhabi", "Mecca", "Beirut", "Petra"],
        ["Saint Elmo", "Saint John", "Saint Nicholas", "Saint Steve"],
        ["Virgo", "Capricorn", "Picses", "Libra"],
        ["Crimean War", "WWI", "WWII", "Vietnam War"],
        ["Turing Test", "Thinking Test", "Beep Test", "Blood Test"],
        ["Mouthwash", "MacDonalds", "Car", "Bus"],
        ["Tea", "Coca Cola", "Coffee", "Mother"],
        ["Video Killed The Radio Star", "Africa", "Thriller", "The Message"],
        ["Bulgaria", "India", "Ukraine", "Mongolia"],
        ["Istanbul", "Mecca", "Tirana", "Islamabad"],
        ["Associated Powers", "The Countries", "EarthGroup", "UnitedEarth"],
        ["Dog", "Cat", "Kangaroo", "Dingo"],
        ["Toyota", "Dodge", "Ford", "Honda"],
        ["Casino Royale", "Goldeneye", "You Only Live Twice", " Moonraker"],
        ["China", "Sign Language", "Triangles", "Sinus infections"],
        ["Harold Holt", "Bob Hawke", "John Howard", "John Batman"],
        ["No Lyrics", "No Music", "No such thing", "really loud"],
        ["Least Likely to succeed", "most funny", "best eyesight", "nothing"],
        ["Tittle", "Dot", "Point", "Period"],
        ["Over 50", "5", "100", "23"],
        ["Seven", "Six", "Eight", "Nine"],
        ["Blue", "Black", "Red", "Green"],
        ["Octothorpe", "Hashtag", "Hash", "Pound"],
        ["Happy Meals", "Big Mac", "Coca Cola", "French Fries"],
        ["Never Spoils", "Medicinal", "Delicious", "Bees"],
        ["Mustapha", "Ali", "Vlad", "Tahir"],
        ["Kentucky Fried Chicken", " Kentucky Flown Craft", "Kraft Food Company", "Kant Find Canswer"],
        ["Killing 9 Headed Dragon", "ankle problems", "Sheperd", "Thief"],
        ["Q and Z", "Y and X", "A and B", "T and S"],
        ["Prague", "Pella", "Hamburg", "Leeds"],
        ["Pisa", "Verona", "Calabria", "Istria"]]
    
    // variable declarations
    var currentTrivia = 0
    var correctAnswerPlacement: UInt32 = 0
    var Score = 0
    
    @IBOutlet weak var triviaTV: UITextView!
    
    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var score: UILabel!
    
    // set the button to equal the answer and add score and append score to label
    @IBAction func answerButtons(_ sender: UIButton) {
        if (sender.tag == Int(correctAnswerPlacement))
        {
            status.text = "Correct"
            Score += 10
            scores.text = "\(Score)"
        }
        else
        {
            status.text = "Incorrect"
        }
        if (currentTrivia != questions.count)
        {
            NewTrivia()
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        NewTrivia()
    }
    
    // randomize the placement of the answers and also navigate through the questions
    func NewTrivia() {
        
        triviaTV.text = questions[currentTrivia]
        correctAnswerPlacement = arc4random_uniform(4)+1
        
        var button: UIButton = UIButton()
        var x = 1
        
        for i in 1...4
        {
            button = self.view.viewWithTag(i) as! UIButton
            
            if (i == Int(correctAnswerPlacement))
            {
                button.setTitle(answers[currentTrivia][0], for: .normal)
            }
            else
            {
                button.setTitle(answers[currentTrivia][x], for: .normal)
                x = 2
            }
        }
        currentTrivia = currentTrivia + 1
    }
    
    @IBOutlet weak var headingTrivia: UILabel!
    
    
    @IBOutlet weak var answerA: RoundedButtons!
    
    // set background to option A and also change text color to red
    @IBAction func btnbgA(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        answerA.setTitleColor(UIColor.red, for: .normal)
        answerB.setTitleColor(UIColor.red, for: .normal)
        answerC.setTitleColor(UIColor.red, for: .normal)
        answerD.setTitleColor(UIColor.red, for: .normal)
        headingTrivia.textColor = UIColor.red
        statusLabel.textColor = UIColor.red
        scoreLabel.textColor = UIColor.red
        scores.textColor = UIColor.red
        triviaTV.textColor = UIColor.red
    }
    
    
    @IBOutlet weak var answerB: RoundedButtons!
    
    // set background to option B and also change text color to gray
    @IBAction func btnbgB(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        answerA.setTitleColor(UIColor.gray, for: .normal)
        answerB.setTitleColor(UIColor.gray, for: .normal)
        answerC.setTitleColor(UIColor.gray, for: .normal)
        answerD.setTitleColor(UIColor.gray, for: .normal)
        headingTrivia.textColor = UIColor.gray
        statusLabel.textColor = UIColor.gray
        scoreLabel.textColor = UIColor.gray
        scores.textColor = UIColor.gray
        triviaTV.textColor = UIColor.gray
    }
    
    
    @IBOutlet weak var answerC: RoundedButtons!
    
    // set background to option C and also change text color to yellow
    @IBAction func btnbgC(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        answerA.setTitleColor(UIColor.yellow, for: .normal)
        answerB.setTitleColor(UIColor.yellow, for: .normal)
        answerC.setTitleColor(UIColor.yellow, for: .normal)
        answerD.setTitleColor(UIColor.yellow, for: .normal)
        headingTrivia.textColor = UIColor.yellow
        statusLabel.textColor = UIColor.yellow
        scoreLabel.textColor = UIColor.yellow
        scores.textColor = UIColor.yellow
        // triviaTV.textColor = UIColor.yellow YELLOW AND GREEN DO NOT MIX
    }
    
    
    // outlet declarations
    @IBOutlet weak var answerD: RoundedButtons!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    
    @IBOutlet weak var scores: UILabel!
    
    
    // set background to default and change text colour to blue
    @IBAction func btnbgD(_ sender: UIButton) {
        BackgroundImage()
        answerA.setTitleColor(UIColor.blue, for: .normal)
        answerB.setTitleColor(UIColor.blue, for: .normal)
        answerC.setTitleColor(UIColor.blue, for: .normal)
        answerD.setTitleColor(UIColor.blue, for: .normal)
        headingTrivia.textColor = UIColor.blue
        statusLabel.textColor = UIColor.blue
        scoreLabel.textColor = UIColor.blue
        scores.textColor = UIColor.blue
        triviaTV.textColor = UIColor.blue
    }
    
    
    @IBOutlet weak var test: UISwitch!
    
    // change buttons to either round or square cornered depending on switch
    @IBAction func customButtons(_ sender: UISwitch) {
        if test.isOn {
            answerA.cornerRadius = 10
            answerB.cornerRadius = 10
            answerC.cornerRadius = 10
            answerD.cornerRadius = 10
        }
        else
        {
            answerA.cornerRadius = 0
            answerB.cornerRadius = 0
            answerC.cornerRadius = 0
            answerD.cornerRadius = 0
        }
    }
    
    // set default background image 
    func BackgroundImage() {
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
