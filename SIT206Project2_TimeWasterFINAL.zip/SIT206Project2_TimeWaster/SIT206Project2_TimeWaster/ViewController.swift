//
//  ViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 26/4/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

// Main Menu Screen


// This class contains the code to segue between the various view controllers

import UIKit

class ViewController: UIViewController {
    
    // Variable declaration
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.BackgroundImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBOutlet weak var heading: UILabel!
    
    // sets the initial background image
    func BackgroundImage() {
        
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    @IBOutlet weak var test: RoundedButtons!
    
    // segue to facts screen
    @IBAction func factsButton(_ sender: UIButton) {
        performSegue(withIdentifier: "factSegue", sender: self)
        
    }
    
    @IBOutlet weak var test2: RoundedButtons!
    // segue to trivia screen
    @IBAction func triviaButton(_ sender: UIButton) {
        performSegue(withIdentifier: "triviaSegue", sender: self)
        
    }
    
    @IBOutlet weak var test3: RoundedButtons!
    
    // segue to leaderboards
    @IBAction func leaderboardButton(_ sender: UIButton) {
        performSegue(withIdentifier: "leaderSegue", sender: self)
        
    }
    
    
    @IBOutlet weak var test4: RoundedButtons!
    
    // segue to settings
    @IBAction func settingsButton(_ sender: UIButton) {
        performSegue(withIdentifier: "settingsSegue", sender: self)
        
    }
    
    
    
    // set background to option A and text color to red
    @IBAction func bgA(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        test.setTitleColor(UIColor.red, for: .normal)
        test2.setTitleColor(UIColor.red, for: .normal)
        test3.setTitleColor(UIColor.red, for: .normal)
        test4.setTitleColor(UIColor.red, for: .normal)
        heading.textColor = UIColor.red
    }
    
    
    // set background to option B and text color to gray
    @IBAction func bgB(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        test.setTitleColor(UIColor.gray, for: .normal)
        test2.setTitleColor(UIColor.gray, for: .normal)
        test3.setTitleColor(UIColor.gray, for: .normal)
        test4.setTitleColor(UIColor.gray, for: .normal)
        heading.textColor = UIColor.gray
    }
    
    // set background to option C and set text color to yellow
    @IBAction func bgC(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        test.setTitleColor(UIColor.yellow, for: .normal)
        test2.setTitleColor(UIColor.yellow, for: .normal)
        test3.setTitleColor(UIColor.yellow, for: .normal)
        test4.setTitleColor(UIColor.yellow, for: .normal)
        heading.textColor = UIColor.yellow
    }
    
    
    // set background back to default but change color of text to blue 
    @IBAction func bgD(_ sender: UIButton) {
        BackgroundImage()
        test.setTitleColor(UIColor.blue, for: .normal)
        test2.setTitleColor(UIColor.blue, for: .normal)
        test3.setTitleColor(UIColor.blue, for: .normal)
        test4.setTitleColor(UIColor.blue, for: .normal)
        heading.textColor = UIColor.blue
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

