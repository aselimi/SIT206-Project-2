//
//  FactsViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class FactsViewController: UIViewController {
    
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
    
    @IBOutlet weak var factView: UITextView!
    
    // go to next fact
    @IBAction func nextButton(_ sender: UIButton) {
        newFact()
    }
    
    // go to previous fact
    @IBAction func previousButton(_ sender: UIButton) {
        prevFact()
    }
    
    
    // array containing all facts (350 facts) 
    let facts = ["Albania was tribal until the 20th century",
                 "Australia has over 10,000 beaches, you could visit a new beach every day for 27 years",
                 "The national animal of Scotland is the unicorn",
                 "Surgeons who play video games at least 3 hours a week perform 27% faster and make 37% fewer errors",
                 "Sonic the Hedgehog has registered itself in the Guiness world record book as the fastest video game character",
                 "2013 was the first year since 1987 to feature four different numbers",
                 "Obsidian blades are sharper than steel blades",
                 "People say bless you when you sneeze because when you sneeze your heart stops for a mili-second",
                 "Rats and horses cant vomit.",
                 "The cigarette lighter was invented before the match",
                 "In every episode of Seinfeld there is a Superman somewhere",
                 "A duck's quack doesnt echo",
                 "In every episode of south park there is an alien somewhere",
                 "Hot water is heavier than cold water",
                 "Deer cant eat hay",
                 "Gorillas sleep for as much as fourteen hours a day",
                 "Ketchup was originally sold as medicine",
                 "Leonardo da vinci invented scissors",
                 "Human thigh bones are stronger than concrete",
                 "Coca cola would be green without colouring",
                 "Earth is the only planet in our solar system not named after a god",
                 "The worlds oldest piece of chewing gum is 9000 years old.",
                 "The average person laughs 10 times a day",
                 "Owls are the only bird who can see blue",
                 "Polar bears are left handed",
                 "1 in 5,000 North Atlantic lobsters is born bright blue",
                 "The average person walks the equivalent of three times around the world in their lifetime",
                 "You cannot snore and dream at the same time",
                 "A broken clock is right twice a day",
                 "Blueberries will not ripen until they are picked",
                 "Coconut water can be used as blood plasma",
                 "Mountain lions can whistle",
                 "On Jupiter and Saturn it rains diamonds",
                 "Rubber bands last longer when refrigerated",
                 "Almonds are a member of the peach family",
                 "Al Capone's business card said he was a used furniture dealer",
                 "Spanish moss is a close relative of the pineapple",
                 "Pumice is the only rock that floats",
                 "Superglue will not stick to teflon",
                 "When astronauts returned from the moon, they had to go through customs",
                 "Romania is the largest balkan country, with an area of 238391KM squared",
                 "Canada is the second largest country on earth",
                 "The video game Grand Theft Auto 5, is the most succesful entertainment product in history",
                 "Sylvester Stallone played rocky balboa",
                 "An alloy of iron, chromium and nickel makes stainless steel",
                 "The national flower of australia is the wattle blossom",
                 "Gavrilo Princip assasinated Archduke Ferdinand, this event is considered one of the events that started the first world war",
                 "Mohammad Reza Shah was the last Shah of Iran",
                 "The main ingredient of a Maron glace is chestnuts",
                 "In Arkansas it is illegal to keep an alligator in your bathtub",
                 "Bart simpsons middle name is jojo",
                 "Ice cream was invented in china",
                 "In British Volumbia it is illegal to kill  a Sasquatch",
                 "The monarch butterfly is the state insect of texas",
                 "Alcohol comes from the arabic word al kohl meaning the essence",
                 "Amazon river dolphins are pink",
                 "There is a brass statue of Winnie The Pooh in Peru",
                 "Wisconsin is known as the badger state",
                 "Xylography is wood engraving",
                 "Fonzies full name on happy days is Arthur Fonzarelli",
                 "The first Apple Mac hardisk was 5MB",
                 "There are 336 dimples on a golf ball",
                 "West End Girls was the debut hit for the Pet Shop Boys",
                 "Flying fish is the national dish of Barbados",
                 "The first name for coffee was bunc",
                 "Stanley Kubrick directed the cult classic Full Metal Jacket",
                 "Napoleon 3 was the last emperor of France",
                 "Paludism is the old name for malaria",
                 "The aardvark is also known as the Earth Pig",
                 "A wumph is a deep thud or noise",
                 "The first ever prime time cartoon show in the us was The Flinstones",
                 "Zion was the name of the hill where Solomon built his temple",
                 "The word coyote comes from aztec language",
                 "Gothic can be a font, architectual style or a novel type",
                 "The ancient egyptians worshipped a sky goddes called nut",
                 "Mushroom is the hen of the woods",
                 "Coffee originated in Ethiopia",
                 "The second longest river in Europe is the Danube",
                 "There are six sides on a standard pencil",
                 "Sterlet is the rarest form of caviar",
                 "The moons astronomical name is the moon",
                 "Cabbages are 91% water",
                 "H202 is the chemical formula of hydrogen peroxide",
                 "Brocolli is a vegetable and a flower",
                 "Italy began the tradition of exchanging Christmas gifts",
                 "Snoopys sister is named Belle",
                 "France invented the clothing button in the 13th century",
                 "Troy mclure appears in the simpsons",
                 "Odin owned geri and freki they were wolves",
                 "Mirabel airport is in Montreal, Canada",
                 "The computer langauge lisp means list processing",
                 "The staple food of the Maori people in New Zealand is the sweet potato",
                 "The Battle of Hastings was fought at Senlac Hill",
                 "The second pillar of Islam, Salah involves daily prayers",
                 "Zagros mountain range is in which country Iran",
                 "Michael Jackson released the album Invincible in 2001",
                 "Vanilla is the only edible orchid",
                 "A moment is exactly 1 minute 30 seconds long",
                 "Popcorn was designed for the microwave",
                 "Fillet of fish was invented so people could have a meatless lent",
                 "Venice is built on 118 islands",
                 "Intel stands for Integrated Electronics",
                 "One Third of the worlds population cant snap their fingers",
                 "A nervous kangaroo licks its forearms",
                 "The process for canning fish was developed in Sardinia",
                 "Socrates was trained to be a stone cutter",
                 "A five wood in golf is commonly called a BAFFY",
                 "Ed Peterson invented the egg mcmuffin",
                 "Saint Michael is the patron saint of grocers",
                 "The scientific name for a gorilla is Gorilla gorilla-gorilla",
                 "Boreas is the greek god of north wind",
                 "A dogrib is also known as A BOAT",
                 "Archimedes lived in syracuse",
                 "Legend has it that toretellini was invented to honour venus' belly button",
                 "An octupus has 3 hearts",
                 "A day on venus is longer than a year on venus",
                 "You can buy a medieval castle cheaper than you can buy a NYC apartment",
                 "Cheese is the most stolen food item in the world",
                 "Snow is actually clear, light refractions make it look white",
                 "Heavy thinking can burn calories",
                 "A sloth takes two weeks to digest its food",
                 "Scotlands national animal is the unicorn",
                 "US presidents must pay for their own meals",
                 "Camels can hold grudges",
                 "Rythym is the longest english word without a vowel",
                 "Slugs have four noses",
                 "In India there is a spa just for elephants",
                 "The first written recipe in the world was for beer",
                 "Heroin was originally marketed as cough medicine",
                 "The word bored was invented in 1823",
                 "Cherophobia is a fear of fun",
                 "The titanic was the first ship to use the sos signal",
                 "Eating chocolate while studying will improve your test scores",
                 "Diet coke was invented in 1982",
                 "The spiral shape of sunflowers follow the fibonnaci sequence",
                 "The fastest red card in the history of football was 2 seconds",
                 "Palm trees are classified as grass",
                 "A great white shark can smell blood from 3 miles away (4.8KM)",
                 "A snail can sleep for 3 years without eating",
                 "The first computer mouse was made out of wood",
                 "Mcdonalds calls frequent buyers heavy users",
                 "There is enough ink in a ballpoint ben to draw a line that is 3 km long",
                 "Antartica is the only continent that doesnt have snakes",
                 "The average strawberry has about 200 seeds",
                 "There are about 4 million google searches every minute",
                 "It is physically impossible for a pig to look up at the sky",
                 "Donald Duck was banned in Finland because he didnt wear pants",
                 "An average pigeon can memorize 1200 images",
                 "A man says average 4850 words in 24 hours",
                 "A typical lead pencil can draw a line that is 35 miles long",
                 "A jiffy is one hundredth of a second",
                 "A shrimps heart is in its head",
                 "In 2008 scientists discovered a new species of bacteria that lives in hairspray",
                 "You have no sense of smell when you are asleep",
                 "Bees have 5 eyes",
                 "80% of millionaires drive used cars",
                 "Most of the worlds maple syrup comes from canada",
                 "The first video game was created in 1958",
                 "Walt disney was afraid of mice",
                 "A tastebud has a lifespan of 10 days",
                 "Spain translates to land of the rabbits",
                 "Hummingbirds cannot walk",
                 "The opposite sides of a dice add up to 7",
                 "It is illegal to chew gum in singapore",
                 "Recycling one glass jar creates enough energy to watch tv for 3 hours",
                 "Starfish have no brains",
                 "Venus is the only planet that rotates clockwise ",
                 "No new animal has been domesticated in 4000 years",
                 "The youngest pope ever was 20 years old",
                 "A crooked nose was a sign of leadership in ancient rome",
                 "95% of all data stored is still stored on paper",
                 "Mickey Mouse was the first non human to win an oscar",
                 "The sum of all numbers on a roulette wheel is 666",
                 "King Henry the 8th slept with a giant axe beside him",
                 "The olympic flags colours are always red, black, blue green and yellow because these 5 colours appear on the flag of every nation on the planet",
                 "San Fransisco's cable cars are the only national monuments that can move",
                 "Women blink twice as much in a day then men do",
                 "An iguana can stay underwater for almost half an hour",
                 "It is possible to lead a cow upstairs, but not downstairs",
                 "A jellyfish is 95 water",
                 "Typerwriter is the longest word that can be typed on one row of keys",
                 "Stewardess is the longest word typed using only the left hand (try it)",
                 "More than half of all people in the world have never made or received a phone call",
                 "On average people fear spiders more than they fear death",
                 "During season 4 of the sopranos james gandolfini gave 16 of his costars 33000 each, saying thanks for sticking by me",
                 "Ironically, the patent for the fire hydrant was lost in a patent office fire",
                 "No 2 cornflakes are identical",
                 "10% of the russian governments income comes from the sale of vodka",
                 "Salmon can jump as high as 6 feet",
                 "Over 90% of all fish caught are caught in the northern hemisphere",
                 "Sharksin was once used as sandpaper",
                 "Amaxaphobia is the fear of riding in a vehicle",
                 "Mitsibushi means three diamonds",
                 "Male butterflies lick stones to get nutrients",
                 "Sharks can blink",
                 "St Martha is the patron saint of housewives",
                 "In Alberta Canada, it is illegal to paint a wooden log",
                 "Astronomy is the worlds oldest science",
                 "By law in china you have to be intelligent to go to school.",
                 "In Boston it is illegal to have a gorilla in the backseat of your car",
                 "96% of american children can recognize ronald macdonald",
                 "Keanu Reeves was born in Beirut, lebanon",
                 "In Vermont it is illegal to whistle underwater",
                 "China was the first country to use pepper",
                 "In oklahoma you need to have a licensed engineer present to open a bottle of soft drink",
                 "In switzerland lawnmowers are illegal on sundays",
                 "More than 15 million muslims visit mecca anually",
                 "A myologist studdies muscles",
                 "The condor is sacred in peru",
                 "Pound for pound hamburgers cost more than new cars",
                 "Jimmy Carter is the first US president to have been born in a hospital",
                 "An average human will grow 590 miles of hair in their lifetime",
                 "90% of people who are struck by lightning survive",
                 "Crayola means oily chalk",
                 "Sheep can recognize other sheep from pictures",
                 "The most productive day of the week is tuesday",
                 "Punctuation was invented in the 15th century",
                 "Antartica has an area code, it is 672",
                 "Vodka actually translates to little water",
                 "Albert Einstein never wore socks",
                 "Streets in japan do not have names",
                 "Despite selling over 80 million albums worldwide,enya has yet to undergo a single concert tour",
                 "The Clash, even at the height of their fame had an open door policy where anyone who wanted to could come backstage",
                 "The Amish population doubles every 21 years",
                 "Michael Jackson had over 1000 unreleased songs on a hard drive at home, which sony bought for 250 million after he died",
                 "The can opener was invented 50 years after the can was",
                 "The film wayne's world was filmed in two weeks",
                 "In England the speaker of the house is not allowed to speak",
                 "Michael Jordan makes more money from nike each year than all the nike factory workers in malaysia combined",
                 "Cockroaches wont eat cucumbers",
                 "Actor Warren Beaty dropped out of university to become a dishwasher",
                 "In North Dakota, it is illegal to sleep with your shoes on",
                 "At Oxford university, it is against the rules to take a sheep into the library",
                 "Egyptian priests weren't allowed to eat onions",
                 "In texas it is illegal to shoot a buffalo from a second story hotel window",
                 "Your eyeballs are 3.5% Salt",
                 "In the 13th century european children were baptised in beer",
                 "The first bagpipes were made from sheeps liver",
                 "The longest cave system in the world is the mammoth cave system in the USA, it is 560,000 Metres deep",
                 "Goats milk is more widely used throughout the world than cows milk",
                 "The chances of making two holes in one in a round of golf are one in 67 million",
                 "Mexico city is sinking at a rate of 18 inches per year",
                 "There are no penguins in the north pole",
                 "Boys who have unusual first names are more likely to have mental health issues than boys with conventional names",
                 "Ants dont sleep",
                 "A fully grown bear can run as fast as a horse",
                 "Anteaters prefer termites to ants",
                 "There exists a beach in new zealand called ninety mile beach, that is exactly 55 miles long",
                 "Coca Cola was the first soft drink consumed in space",
                 "Petrol will never freeze",
                 "One in 20 people are born with an extra rib",
                 "The average lifespan of a dragonfly is 24 hours.",
                 "Bill Gates' house was designed using a Macintosh computer",
                 "Pain travels through the body at 350ft per second.",
                 "There are no ants in Iceland, Antartica or Greenland",
                 "A single ounce of platinum can be strechted 10000 feet",
                 "Bluebirds cant see the colour blue",
                 "A tuna fish can swim 100 miles in a single day",
                 "Men are 6 times more likely to be struck by lightning than women",
                 "Any modern jet is capable of breaking the sound barrier",
                 "It takes six months to build a rolls royce, and thirteen hours to build a toyota",
                 "Only 1% of bacteria cause disease",
                 "Fine grained organic ash can be found as an ingerient in toothpaste",
                 "Black bears are not always black, they can be brown, cinnamon, yellow and sometimes white",
                 "An elephants tooth can weigh as much as 5 kilos",
                 "Right handed people live on average, nine years longer than left handed people",
                 "More than one quarter of the worlds forests are located in siberia",
                 "Dogs and cats are either right or left handed",
                 "Grapes explode when you put them in the microwave",
                 "Avocados are poisonous to birds",
                 "Americans are responsible for one fifth of all garbage on earth",
                 "The creator of the nike swoosh symbol was paid only $35 for the design",
                 "Penguins can convert salt water into fresh water",
                 "Milk is heavier than cream",
                 "Sweat is odourless, it is the bacteria on the skin that creates an odour",
                 "The most pushups ever performed in one day was 46001",
                 "Organized crime is estimated to account for 10% of the united states national income",
                 "A man by the name of Charles Osborne had the hiccups for approximately sixty nine years",
                 
                 "The US Army packs tabasco pepper sauce in every ration kit that they give to soldiers",
                 "It takes four hours to hard boil an ostrich egg",
                 "Dragonflies have six legs but cannot walk",
                 "Each day is longer than the last, so much so that this adds up to an extra 13 seconds each century!",
                 "Grenades were invented in china over 1000 years ago",
                 "Out of all the senes, smell is most closely linked to memory",
                 "Almost all varieties of breakfast cereal are made from grass",
                 "It takes one week to make a single jelly bean",
                 "A fire in australia has been burning for more than 5000 years",
                 "Actor harrison ford has a species of spider named after him",
                 "Turtles can live for more than 100 years",
                 "Oenophobia is the fear of wines",
                 "A small airplane can fly backwards",
                 "Dirty snow melts faster than clean snow",
                 "Oil tycoon John D. Rockefeller was the worlds first billionaire",
                 "There are no rental cars in bermuda",
                 "Vultures fly without flapping their wings",
                 "Australia is the worlds largest inhabited island and is the smallest continent",
                 "Fifty percent of Australia has less than 300 millimetres annual rainfall",
                 "The average australian in his lifetime, can expect to eat during their lifetime, 17 beef cattle, 92 sheep, 406 loaves of bread, 165000 eggs, 8 tons of fruit, half a ton of cheese and ten tons of vegetables.",
                 "The oldest daily newspaper in the southern hemisphere is the Sydney Morning Herald (1831)",
                 "Western Australia is 3 and a half times bigger than Texas",
                 "The australian coastline totals 36,735 kilometres",
                 "Medical studies show that intelligent people have more copper and zinc in their hair",
                 "Bamboo plants can grow up to 3 feet per day",
                 "Bananas are technically herbs",
                 "Ears of corn will always have an even number of kernels",
                 "Ducks will only lay eggs early in the morning",
                 "In Holland you can be fined for not using a basket when shopping",
                 "On some Carribean islands, the oysters can climb trees",
                 "The nestle family havent run nestle since 1875",
                 "Pretzels were invented for christains to eat during lent",
                 "A woodpecker can peck twenty times a second",
                 "It is illegal to own a red car in shanghai, china",
                 "An olive tree can live up to 1500 years",
                 "All species of beetles are edible",
                 "The average life span of a hermit crab is 75 years",
                 "Clinophobia is the fear of beds",
                 "In West Virginia it is illegal to cook cabbage",
                 "A can of WD40 can be found in 4/5 American homes",
                 "In Kansas it is illegal to eat a cherry pie with ice cream",
                 "In Cheyenne Wyoming it is illegal to shower on wednesday",
                 "One in four americans has been on television",
                 "Famous musician Rod Stewart was once a gravedigger",
                 "Contrary to popular belief the distress message SOS doesnt stand for anything",
                 "Goats have rectangular pupils",
                 "Dwight Eisenhower was the first president to hold a pilots license",
                 "A fisherman in the arral sea had his boat destroyed by a cow that the us airforce had dumped from a plane",
                 "It was illegal to smoke in Tsarist Russia",
                 "The best wood for making pencils is Incense Cedar",
                 "The average economy class meal costs just $4, in business its $50",
                 "Bats always turn left when exiting a cave",
                 "You share your birthday with at least 9 million people in the world",
                 "The inventor of the waffle iron did not like waffles ",
                 "McDonalds is the worlds largest distributor of toys ",
                 "The earth actually has two moons",
                 "There are 53 lego bricks for every person in the world",
                 "Mr Rogers was an ordained minister",
                 "Dogs can hear sounds humans cant.",
                 "Oak trees get struck by lightning more than any other tree",
                 "The United Kingdom eats more cans of baked beans than the rest of the world combined ",
                 "Apples are 25% air",
                 "Car accidents rise by 10% during the first week of daylight savings time",
                 "San Fransicso's chinatown is the worlds largest chinese settlement outside of China",
                 "The only digital rolex in the world is found at Wimbeldons Centre court",
                 "In ancient sparta, bachelors couldnt watch womens gymnastics",
                 "The largest moon in our solar system is Ganymede of jupiter, it is bigger than mercury",
                 "The colour green is the first mentioned colour in the bible",
                 "Mageiricophobia is the fear of cooking",
                 "According to a study, the state of nevada drinks the most alcohol per person",
                 "The Aztecs thought that chocolate was the food of the gods",
                 "Sound travels 15 times faster through steel than through air"]
    /*
     References, All Facts and Trivia were obtained from the following links
     http://bootstrike.com/LaughterHell/Misc/miscs13.php
     https://www.cs.cmu.edu/~bingbin/
     https://www.livin3.com/50-cool-and-weird-fun-facts-that-you-should-know
     https://dan.hersam.com/lists/trivia.html
     http://www.keloo.ro/doc/10000_intrebari.pdf
     https://www.quora.com/What-are-some-interesting-random-facts
     https://owlcation.com/misc/Over-200-Odd-Facts-Did-You-Know-Them
     http://www.managementparadise.com/forums/articles/18084-list-over-300-unusual-interesting-facts.html
     https://factrepublic.com/50-random-facts-list-75/2/
     https://www.goway.com.au/travel-information/australia-south-pacific/australia/oz-trivia-fun-facts/
     */
    
    // variable declarations
    
    var currentFact = 0
    var previFact = -1
    
    // function to go up one index, also updates the progress.
    func newFact() {
        if currentFact < facts.count
        {
            progressLabel.text = "\(currentFact)"
            factView.text = facts[currentFact]
            
            if currentFact < facts.count {
                currentFact += 1
                progressLabel.text = "\(currentFact)"
            }
        }
    }
    
    // function to go back one index, also updates progress
    func prevFact() {
        if currentFact > 0
        {
            progressLabel.text = "\(currentFact)"
            factView.text = facts[currentFact]
            if currentFact < facts.count
            {
                currentFact -= 1
                progressLabel.text = "\(currentFact)"
            }
        }
    }
    
    
    // outlet declarations
    @IBOutlet weak var of: UILabel!
    @IBOutlet weak var factsHeading: UILabel!
    @IBOutlet weak var factsTV: UITextView!
    @IBOutlet weak var progressLabel: UILabel!
    
    // set background to option A and change text color to red
    @IBAction func chooseA(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280")
        }
        factsHeading.textColor = UIColor.red
        factsTV.textColor = UIColor.red
        progressLabel.textColor = UIColor.red
        of.textColor = UIColor.red
    }
    
    // set background to B and change text color to gray
    @IBAction func ChooseB(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        factsHeading.textColor = UIColor.gray
        factsTV.textColor = UIColor.gray
        progressLabel.textColor = UIColor.gray
        of.textColor = UIColor.gray
    }
    
    // set background to C and change text color to yellow
    @IBAction func ChooseC(_ sender: UIButton) {
            if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
            {
                backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
            }
            else
            {
                backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
            }
        factsHeading.textColor = UIColor.yellow
        factsTV.textColor = UIColor.black
        progressLabel.textColor = UIColor.yellow
        of.textColor = UIColor.yellow
    }
    
    // set background to D and change text color to blue
    @IBAction func ChooseD(_ sender: UIButton) {
        BackgroundImage()
        factsHeading.textColor = UIColor.blue
        factsTV.textColor = UIColor.blue
        progressLabel.textColor = UIColor.blue
        of.textColor = UIColor.blue
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
        newFact()
    }

    // set default background image 
    func BackgroundImage() {
        
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
