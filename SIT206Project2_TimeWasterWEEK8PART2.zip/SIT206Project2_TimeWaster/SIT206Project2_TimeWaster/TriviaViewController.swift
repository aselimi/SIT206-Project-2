//
//  TriviaViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {

    let questions = ["Which tv gangster owns a nightclub called the Ba Da Bing?",
                     "Andrew Patterson wrote which Australian song?",
                     "The Sumi people live were?",
                     "Pomono was the roman godess of what?",
                     "Galileo was born in which city?"]
    
    let answers = [["Silvio Dante", "Tony Soprano", "Henry Hill", "Ace Rothstein"],
        ["Waltzing Matilda", "24K Magic", "Proud Mary", "Cut It Short"],
        ["Lapland", "Prague", "Naples", "Alice Springs"],
        ["Fruit Trees", "Fertility", "Olives", "Sky"],
        ["Pisa", "Verona", "Calabria", "Istria"]]
    
    var currentTrivia = 0
    var correctAnswerPlacement: UInt32 = 0
    var Score = 0
    
    @IBOutlet weak var triviaTV: UITextView!
    
    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var score: UILabel!
    
    
    @IBAction func answerButtons(_ sender: UIButton) {
        if (sender.tag == Int(correctAnswerPlacement))
        {
            status.text = "Correct"
            Score += 1
        }
        else
        {
            status.text = "Incorrect"
        }
        if (currentTrivia != questions.count)
        {
            NewTrivia()
        }
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        NewTrivia()
    }
    
    func NewTrivia() {
        
        triviaTV.text = questions[currentTrivia]
        correctAnswerPlacement = arc4random_uniform(4)+1
        
        var button: UIButton = UIButton()
        var x = 1
        
        for i in 1...4
        {
            button = self.view.viewWithTag(i) as! UIButton
            
            if (i == Int(correctAnswerPlacement))
            {
                button.setTitle(answers[currentTrivia][0], for: .normal)
            }
            else
            {
                button.setTitle(answers[currentTrivia][x], for: .normal)
                x = 2
            }
        }
        currentTrivia = currentTrivia + 1
    }
    
    
    
    func BackgroundImage() {
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
