//
//  LeaderboardsViewController.swift
//  SIT206Project2_TimeWaster
//
//  Created by ALUSH SELIMI on 1/5/18.
//  Copyright © 2018 ALUSH SELIMI. All rights reserved.
//

import UIKit

class LeaderboardsViewController: UIViewController {
    
    let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
    
    func BackgroundImage() {
        backgroundImage.image = UIImage(named: "wooden-boards-3339145_1280.jpg")
        backgroundImage.contentMode = UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
    }
    
    
    @IBAction func btnA(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "background-image-3326841_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "background-image-3326841_1280.jpg")
        }
    }
    
    
    @IBAction func btnB(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "blue-3222534_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "blue-3222534_1280.jpg")
        }
    }
    
    
    @IBAction func btnC(_ sender: UIButton) {
        if (backgroundImage.image != UIImage(named: "wall-3294437_1280.jpg"))
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
        else
        {
            backgroundImage.image = UIImage(named: "wall-3294437_1280.jpg")
        }
    }
    
    
    @IBAction func btnD(_ sender: UIButton) {
        BackgroundImage()
    }
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.BackgroundImage()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
